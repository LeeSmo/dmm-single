package com.zzg.mybatis.generator;

import javafx.application.Application;

/**
 * @author 欧闻
 * @version $Id: Main, v 0.1 2021/4/20 欧闻 Exp $$
 */
public class Main {

    public static void main(String[] args) {
        Application.launch(MainUI.class);
    }

}
